const express = require('express');
const { body } = require('express-validator');

const router = express.Router();

const usersCtrl = require('../controllers/users-controller');

router.get('/', usersCtrl.index);

router.get('/details/:userid', usersCtrl.details);

router.get('/create', usersCtrl.create_get);

router.post('/create', body('email').isEmail(), usersCtrl.create_post);

router.get('/edit/:userid', usersCtrl.edit_get);

router.post('/edit/:userid', usersCtrl.edit_post);

router.get('/delete/:userid', usersCtrl.delete_get);

router.post('/delete/:userid', usersCtrl.delete_post);

module.exports = router;
