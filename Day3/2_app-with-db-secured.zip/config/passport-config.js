const LocalStrategy = require('passport-local').Strategy;

module.exports = function (passport) {
    passport.serializeUser(function (user, done) {
        done(null, user);
    });

    passport.deserializeUser(function (user, done) {
        done(null, user);
    });

    passport.use('local-login', new LocalStrategy({
        usernameField: 'email',
        passwordField: 'password',
        passReqToCallback: true
    }, function (req, email, password, done) {
        // Code to Read Username & Password from a database or a file

        if (email != "manish@abc.com")
            return done(null, false, req.flash('loginMessage', 'Authentication Failed - User not Found!'));

        if (password != "manish")
            return done(null, false, req.flash('loginMessage', 'Authentication Failed - Wrong Password!'));

        var user = { email, password };

        return done(null, user);
    }));
}

// The user which we provided as the second argument of the done function, will be saved in the session
// and will be later used to retrieve the whole object via the de-serializeUser function

// serializeUser determines which data of the user object should be stored in the session.
// The result of the serializeUser method is attached to the session as req.session.passport.user = {}.