const express = require('express');
const router = express.Router();

const accountCtrl = require('../controllers/account-controller');

module.exports = function (passport) {
    router.get('/', function (req, res, next) {
        res.redirect('account/login');
    });

    router.get('/login', accountCtrl.login_get);

    router.post('/login', accountCtrl.login_post(passport));

    return router;
};
