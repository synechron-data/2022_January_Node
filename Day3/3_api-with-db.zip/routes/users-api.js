const express = require('express');

const router = express.Router();
var cors = require('cors');

const usersApiCtrl = require('../controllers/users-api-controller');

// const corsOptions = {
//     // origin: 'https://www.synechron.com',
//     // origin: 'http://localhost:4000',
//     origin: ['https://www.synechron.com', 'http://localhost:4000'],
// }

// router.use(cors(corsOptions));
router.use(cors());

router.get('/', usersApiCtrl.getAllUsers);

module.exports = router;
