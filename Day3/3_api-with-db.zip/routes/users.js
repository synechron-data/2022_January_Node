const express = require('express');

const router = express.Router();

const accountCtrl = require('../controllers/account-controller');
const usersCtrl = require('../controllers/users-controller');

router.use(accountCtrl.isAuthenticated);

router.get('/', usersCtrl.index);

module.exports = router;
