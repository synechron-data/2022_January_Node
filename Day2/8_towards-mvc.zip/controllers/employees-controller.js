const da = require('../data-access');

exports.index = (req, res, next) => {
    res.render("employees/index", { pageTitle: "Employees View", empList: da.getAllEmployees() });
}

exports.details = (req, res, next) => {
    var id = req.query.id || req.params.empid;
    res.render("employees/details", { pageTitle: "Employee Details View", employee: da.getEmployee(id) });
}