class Logger {
    log(message) {
        console.log(`${message}, logged using Logger class Method`);
    }
}

let instance;

exports.getLogger = function () {
    if (!instance)
        instance = new Logger();
    return instance;
}