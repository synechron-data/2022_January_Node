const Logger = require('./Logger');
let instance;

exports.getLogger = function () {
    if (!instance)
        instance = new Logger();
    return instance;
}