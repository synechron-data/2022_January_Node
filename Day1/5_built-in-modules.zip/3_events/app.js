// Every action which you perform on your computer system is an event

// var events = require('events');
// var eEmitter = new events.EventEmitter();

// // Subscribe
// eEmitter.addListener('test', () => {
//     console.log("Listener Code Executed....");
// });

// // Publish
// eEmitter.emit("test");

// ------------------------------------------------------

const StringEmitter = require('./StringEmitter');
const sEmitter = new StringEmitter();

// var s = sEmitter.getString();
// console.log(s);

// setInterval(function () {
//     var s = sEmitter.getString();
//     console.log(s);
// }, 2000);

// Call 1 - 1500
// Call 2 - 3000
// Call 3 - 1000

// ------------------------------------
// sEmitter.pushString(function (s) {
//     console.log("S1 -", s);
// });

// sEmitter.pushString(function (s) {
//     console.log("S2 -", s);
// });

// ------------------------------------

sEmitter.on('data', (s) => {
    console.log("S1 -", s);
});

// sEmitter.on('data', (s) => {
//     console.log("S2 -", s);
// });

let count = 0;

function S2(s) {
    console.log("S2 -", s);
    ++count;
    if (count > 2) {
        sEmitter.removeListener('data', S2);
    }
}

sEmitter.on('data', S2);